# stack-sample
reduced release version of a stackoverflow dump
